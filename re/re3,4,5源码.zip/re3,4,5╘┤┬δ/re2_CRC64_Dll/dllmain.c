﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#define  _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <windows.h>
__int64 dq_key = 88777897;
char datacmp[] = {
    0x4D,0xB8,0x76,0x29,0xF5,0xA9,0x9E,0x59,
    0x55,0x56,0xB1,0xC4,0x2F,0x21,0x2C,0x30,
    0xB3,0x79,0x78,0x17,0xA8,0xED,0xF7,0xDB,
    0xE1,0x53,0xF0,0xDB,0xE9,0x03,0x51,0x5E,
    0x09,0xC1,0x00,0xDF,0xF0,0x96,0xFC,0xC1,
    0xB5,0xE6,0x62,0x95,0x01,0x00,0x00,0x00,
};

//是char*,不是wchar
struct my_UNICODE {
    size_t len;
    size_t max_len;
    UCHAR* data;
}my_UNICODE;

void fenc(struct my_UNICODE* txtInput)
{
    long long* lp;
    long long mem_dq;
    int i, j;
    //一次性加密8位
    for (i = 0; i < txtInput->len / 8; i++)//
    {
        lp = &txtInput->data[i * 8];
        mem_dq = *lp;
        for (j = 0; j < 64; j++)
        {
            if (mem_dq >= 0)
            {
                mem_dq = mem_dq << 1;
            }
            else
            {
                mem_dq = (mem_dq << 1) ^ dq_key;
            }
        }
        *lp = mem_dq;
    }
    //for (i = 0; i <txtInput->len/8; i++)
    //{
    //    for (j = 0; j < 8; j++)
    //    {
    //        printf("0x%02X,", txtInput->data[i * 8 + j]);
    //    }
    //    printf("\n");
    //}
    //printf("\n");
    return;
}
//void fdec()
//{
//
//    BYTE flag[48] = {
//    0x4D,0xB8,0x76,0x29,0xF5,0xA9,0x9E,0x59,
//    0x55,0x56,0xB1,0xC4,0x2F,0x21,0x2C,0x30,
//    0xB3,0x79,0x78,0x17,0xA8,0xED,0xF7,0xDB,
//    0xE1,0x53,0xF0,0xDB,0xE9,0x03,0x51,0x5E,
//    0x09,0xC1,0x00,0xDF,0xF0,0x96,0xFC,0xC1,
//    0xB5,0xE6,0x62,0x95,0x01,0x00,0x00,0x00,
//
//    };
//    __int64 p;
//    int j, i;
//    for (i = 0; i < 6; i++)
//    {
//        p = *((__int64*)&flag[i * 8]);
//        for (j = 0; j < 64; j++)
//        {
//            if (p & 1) //其实这就是根据某个特征来的
//            {
//                p = ((unsigned __int64)p ^ dq_key) >> 1;
//                p |= 0x8000000000000000;//还原那个符号位1 
//
//            }
//            else
//            {
//                p = (unsigned __int64)p >> 1;
//            }
//        }
//        *((__int64*)&flag[i * 8]) = p;
//    }
//    for (i = 0; i < 48; i++)
//        printf("%c", flag[i]);
//    printf("\n");
//    return;
//}


int main1()
{
    //"D0g3{60E1E72A-576A8BF0-7701CBB9-B02415EC}";
    struct my_UNICODE* txtInput = VirtualAlloc(NULL, sizeof(struct my_UNICODE) + 65536, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (txtInput == NULL) {
        return -1;
    }
    txtInput->max_len = 65536;
    txtInput->len = 0;
    txtInput->data = (char*)txtInput + sizeof(struct my_UNICODE);
    memset(txtInput->data, 0, txtInput->max_len);
    printf("[out]: PLZ Input FLag \n");
    printf("[in ]: ");
    scanf("%s", txtInput->data);
    txtInput->len = strlen(txtInput->data);

    if (txtInput->len != 41) {
        printf("[out]: len error\n");
        VirtualFree(txtInput, 0, MEM_RELEASE | MEM_DECOMMIT);
        return -1;
    }
    //加密
    txtInput->len = 48;
    fenc(txtInput);
    if (!memcmp(txtInput->data, datacmp, 48)) {
        printf("[out]: RIGHT FLAG\n");
    }
    else {
        printf("[out]: WRONG FLAG\n");
    }
    VirtualFree(txtInput, 0, MEM_RELEASE | MEM_DECOMMIT);
    //fdec();
    return 0;
}
BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:
        main1();
        break;
    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

