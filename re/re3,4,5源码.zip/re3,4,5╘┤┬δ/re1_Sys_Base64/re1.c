//#include<ntddk.h>
//HANDLE g_file
////У��
#include <ntifs.h>
#include <ntstrsafe.h>

unsigned char sbox[64] = { 0 };
void swap(unsigned char* a, unsigned char* b)
{
    unsigned char tmp = *a;
    *a = *b;
    *b = tmp;
}
void init_sbox(unsigned char *key,int Klen) {
    for (unsigned int i = 0; i < 64; i++)//��ֵ
        sbox[i] = i;
    unsigned char Ttable[64] = { 0 };
    for (int i = 0; i < 64; i++)
        Ttable[i] = key[i % Klen];//���ݳ�ʼ��t��
    for (int j = 0, i = 0; i < 64; i++)
    {
        j = (j + sbox[i] + Ttable[i]) % 64;	//����s��
        swap(&sbox[i], &sbox[j]);
    }
}
void RC4_enc_dec(unsigned char* data, unsigned int dLen, unsigned char * key,int Klen) {
    unsigned char k, i = 0, j = 0, t;
    init_sbox(key,Klen);
    for (unsigned int h = 0; h < dLen; h++)
    {
        i = (i + 1) % 64;
        j = (j + sbox[i]) % 64;
        swap(&sbox[i], &sbox[j]);
        t = (sbox[i] + sbox[j] + (i ^ j)) % 64;
        k = sbox[t];	//����Կ��,�������ļ���
        data[h] ^= (k & (i ^ j));
    }
}
// ��ȡ�ļ�����
BOOLEAN MyReadFile(UNICODE_STRING ustrFileName, LARGE_INTEGER liOffset, PUCHAR pReadData, PULONG pulReadDataSize)
{
	HANDLE hFile = NULL;
	IO_STATUS_BLOCK iosb = { 0 };
	OBJECT_ATTRIBUTES objectAttributes = { 0 };
	NTSTATUS status = STATUS_SUCCESS;

	// ��ʼ���ṹ
	InitializeObjectAttributes(&objectAttributes, &ustrFileName, OBJ_CASE_INSENSITIVE | OBJ_KERNEL_HANDLE, NULL, NULL);

	// ���ļ�
	status = ZwCreateFile(&hFile, GENERIC_READ, &objectAttributes, &iosb, NULL, FILE_ATTRIBUTE_NORMAL, FILE_SHARE_READ | FILE_SHARE_WRITE, FILE_OPEN, FILE_NON_DIRECTORY_FILE | FILE_SYNCHRONOUS_IO_NONALERT, NULL, 0);
	if (!NT_SUCCESS(status))
	{
		return FALSE;
	}

	// ��ʼ��
	RtlZeroMemory(&iosb, sizeof(iosb));

	// �����ļ�
	status = ZwReadFile(hFile, NULL, NULL, NULL, &iosb, pReadData, *pulReadDataSize, &liOffset, NULL);
	if (!NT_SUCCESS(status))
	{
		*pulReadDataSize = iosb.Information;
		ZwClose(hFile);
		return FALSE;
	}

	// ��ȡʵ�ʶ�ȡ������
	*pulReadDataSize = iosb.Information;

	// �رվ��
	ZwClose(hFile);

	return TRUE;
}
BOOLEAN b64check(PCHAR flag, int Length) {

    CHAR* data = "6zviISn2McHsa4b108v29tbKMtQQXQHA+2+sTYLlg9v2Q2Pq8SP24Uw=";
    if (Length != 56) {
        goto tag_deal;
    }
    if (!memcmp(flag, data, 56))
    {
        return TRUE;
    }
tag_deal:
    return FALSE;
}
////����
NTSTATUS b64(UCHAR* txtOutput, UCHAR* txtInput, int Length) {

    int i, j;
    char t64[] = "4KBbSzwWClkZ2gsr1qA+Qu0FtxOm6/iVcJHPY9GNp7EaRoDf8UvIjnL5MydTX3eh";//������һ���ط�,�������һ��
    for (i = 0, j = 0; i < Length; i += 3, j += 4)
    {
        //��&�ķ���,,����Ϊ��������һ������Ķ�����ȥ..û�µ�..û�µ�
        txtOutput[j + 0] = t64[txtInput[i + 0] & 0b00111111];//1
        txtOutput[j + 1] = t64[(((txtInput[i + 0] & 0b11000000)) >> 6) | ((txtInput[i + 1] & 0b00001111) << 2)];
        txtOutput[j + 2] = t64[((txtInput[i + 1] & 0b11110000) >> 4) | ((txtInput[i + 2] & 0b11) << 4)];
        txtOutput[j + 3] = t64[(txtInput[i + 2] & 0b11111100) >> 2]; 
    }
    switch (Length % 3)
    {
    case 1:
        txtOutput[j - 2] = '=';
        txtOutput[j - 1] = '=';
        break;
    case 2:
        txtOutput[j - 1] = '=';
        break;
    }
    return  STATUS_SUCCESS;
}
NTSTATUS mainWork()
{

    UNICODE_STRING ustrScrFile;
    ULONG ulBufferSize = 4096;
    LARGE_INTEGER liOffset = { 0 };
    NTSTATUS status;
    BOOLEAN bstatus;
 
    // ��ʼ����Ҫ��ȡ���ļ���
    RtlInitUnicodeString(&ustrScrFile, L"\\??\\C:\\Users\\Public\\flag.txt");

    // ����Ƿ�ҳ�ڴ�
    PUCHAR pInput = ExAllocatePool(NonPagedPool, ulBufferSize);
    PVOID pOutput = ExAllocatePool(NonPagedPool, ulBufferSize);

    if (pInput == NULL || pOutput == NULL) {
        DbgPrint("tips: can not malloc\n");
        goto  tag_free;
    }
    memset(pOutput, 0, ulBufferSize);
    memset(pInput, 0, ulBufferSize);

    // ��ȡ�ļ�
    bstatus = MyReadFile(ustrScrFile, liOffset, pInput, &ulBufferSize);
    if (bstatus == FALSE) {
        DbgPrint("tips: can not read|open file\n");
        goto tag_free;
    }

    if (ulBufferSize > 3072) {
        DbgPrint("tips: file to long \n");
        //����̫����
        goto tag_free;
    }
    //RC4
    RC4_enc_dec(pInput, ulBufferSize, "the_key_", 8);
    //b64
    b64( pOutput, pInput, ulBufferSize);
    //check
    bstatus = b64check(pOutput, 56);
    CHAR* szOK = "tips: YES, RIGHT FLAG.   you got it!";
    CHAR* szNO = "tips: NO , WRONG ANSWER. try again !";
    //д���жϵĽ��

    if (bstatus==FALSE) {
        DbgPrint("tips: %s\n", szNO);
    }
    else {
        DbgPrint("tips: %s\n", szOK);
    }

tag_free:
    // �ͷ��ڴ�
    if (pInput != NULL) {
        ExFreePool(pInput);
        pInput = NULL;
    }
    // �ͷ��ڴ�
    if (pOutput != NULL) {
        ExFreePool(pOutput);
        pOutput = NULL;
    }
    return 0;
}
VOID UnDriver(PDRIVER_OBJECT driver)
{
	DbgPrint("tips: good bye ...\n");
}

NTSTATUS DriverEntry(IN PDRIVER_OBJECT Driver, PUNICODE_STRING RegistryPath)
{

	DbgPrint("tips: welcome ...\n");
   // DbgBreakPoint();
    mainWork();
	Driver->DriverUnload = UnDriver;
	return STATUS_SUCCESS;
   
}
