// demo-mmloader-static.cpp : Defines the entry point for the console application.
//
 
#include <tchar.h>
#include <windows.h>
#include <strsafe.h>
#include "mmLoader.h"
#include "resource.h" 
//
//class AutoReleaseModuleBuffer 
//{
//public:
//    AutoReleaseModuleBuffer(LPCTSTR szDllPath) : m_pBuffer(NULL), m_hFileMapping(NULL), m_hFile(NULL) 
//    {
//        // Open the module and read it into memory buffer
//        m_hFile = ::CreateFile(
//            szDllPath, 
//            GENERIC_READ, 
//            FILE_SHARE_READ, 
//            NULL, 
//            OPEN_EXISTING, 
//            NULL, NULL);
//
//        if (INVALID_HANDLE_VALUE == m_hFile || NULL == m_hFile) 
//        {
//            _tprintf(_T("Failed to open the file: %s\r\n"), szDllPath);
//            return;
//        }
//
//        // Check file size
//        DWORD dwFileSize = ::GetFileSize(m_hFile, NULL);
//        if (INVALID_FILE_SIZE == dwFileSize || dwFileSize < sizeof(IMAGE_DOS_HEADER)) 
//        {
//            ::CloseHandle(m_hFile);
//            m_hFile = NULL;
//            _tprintf(_T("Invalid file size: %d\r\n"), dwFileSize);
//            return;
//        }
//
//        m_hFileMapping = ::CreateFileMapping(m_hFile, 0, PAGE_READONLY, 0, 0, NULL);
//        if (NULL == m_hFileMapping) {
//            ::CloseHandle(m_hFile);
//            m_hFile = NULL;
//            _tprintf(_T("Failed to create file mapping.\r\n"));
//            return;
//        }
//
//        m_pBuffer = ::MapViewOfFile(m_hFileMapping, FILE_MAP_READ, 0, 0, 0);
//        if (NULL == m_pBuffer) {
//            ::CloseHandle(m_hFileMapping);
//            ::CloseHandle(m_hFile);
//            m_hFileMapping = NULL;
//            m_hFile = NULL;
//            _tprintf(_T("Failed to map view of the file.\r\n"));
//        }
//    }
//
//    ~AutoReleaseModuleBuffer() {
//        Release(); 
//    }
//
//    void Release() 
//    {
//        if (m_pBuffer) {
//            ::UnmapViewOfFile(m_pBuffer);
//            m_pBuffer = NULL;
//        }
//
//        if (m_hFileMapping) {
//            ::CloseHandle(m_hFileMapping);
//            m_hFileMapping = NULL;
//        }
//
//        if (m_hFile) {
//            ::CloseHandle(m_hFile);
//            m_hFile = NULL;
//        }
//    }
//
//    operator LPVOID() 
//    { 
//        return m_pBuffer; 
//    }
//
//private:
//    LPVOID m_pBuffer;
//    HANDLE m_hFile;
//    HANDLE m_hFileMapping;
//};
// 
PVOID findRes() 
{
    HMODULE moduleHandle = GetModuleHandle(NULL); // ��ȡ��ǰ��ִ���ļ���ģ����

// ������Դ
    HRSRC resourceHandle = FindResource(moduleHandle, MAKEINTRESOURCE(IDR_COM1), "com");
    if (resourceHandle == NULL) {
        printf("Failed to find the resource.\n");
        return 0;
    }

    // ��ȡ��Դ��С
    DWORD resourceSize = SizeofResource(moduleHandle, resourceHandle);
    if (resourceSize == 0) {
        printf("Failed to get the resource size.\n");
        return 0;
    }

    // ������Դ���ڴ�
    HGLOBAL resourceDataHandle = LoadResource(moduleHandle, resourceHandle);
    if (resourceDataHandle == NULL) {
        printf("Failed to load the resource.\n");
        return 0;
    }

    // ��ȡ��Դ����ָ��
    LPVOID resourceData = LockResource(resourceDataHandle);
    if (resourceData == NULL) {
        printf("Failed to lock the resource.\n");
        return 0;
    }

    // ����һ�����������洢��Դ����
    LPVOID buffer = VirtualAlloc(NULL, resourceSize, MEM_COMMIT | MEM_RESERVE, PAGE_READWRITE);//resourceSize
    if (buffer == NULL) {
        printf("Failed to allocate memory.\n");
        return 0;
    }

    // ����Դ���ݸ��Ƶ�������
    memcpy(buffer, resourceData, resourceSize);
    // ����ͷ���Դ�ͻ�����
    FreeResource(resourceDataHandle);
    return buffer;
    // ʹ�û������е���Դ���ݣ�������Ը��ݾ���������д���


    //VirtualFree(buffer, 0, MEM_RELEASE);
}
int main() 
{
    PVOID buffer = 0;// findRes();
   
    HMEMMODULE hMemModule = NULL;
    DWORD dwErrorCode = 0;

    buffer = findRes();
    if (buffer == NULL) {
        printf("find res failed\n");
        return 0;
    }
    hMemModule = (HMEMMODULE)MemModuleHelper(MHM_BOOL_LOAD, buffer, (LPVOID)TRUE, &dwErrorCode);
    VirtualFree(buffer, 0, MEM_RELEASE);
    return dwErrorCode;
}