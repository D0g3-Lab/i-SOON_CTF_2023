#include <Windows.h>
#include <stdio.h>
#include "test.h"

typedef void (* xx)(DWORD*, DWORD*);

class crypto {

public:
    crypto() {
        
    }
    crypto(BYTE* lp_key,int dw_keyLen) {

        m_lp_key = new BYTE[dw_keyLen];
        //m_lp_key = (BYTE*)malloc(dw_keyLen);
        memcpy(m_lp_key, lp_key, dw_keyLen);
        m_dw_keyLen = dw_keyLen;
    }
    ~crypto() {

        if (m_lp_key) {
            delete[] m_lp_key;
        }
        if (m_lp_enc_data) {
            delete[] m_lp_enc_data;
        }
        if (m_lp_dec_data) {
            delete[] m_lp_dec_data;
        }
        if (m_lp_output) {
            delete[] m_lp_output;
        }
    }
    virtual void enc() {
        return;
    }
    virtual void dec() {
        return;
    }
    virtual void show_enc(int)=0;
    virtual void show_dec(int) = 0;
    virtual void show_output(int) = 0;
    
protected:
    BYTE* m_lp_key=0;
    DWORD m_dw_keyLen=0;
 
    BYTE* m_lp_enc_data=0;
    BYTE* m_lp_dec_data = 0;
    BYTE* m_lp_output=0;
    DWORD m_dw_dataLen = 0;
};
class BlowFish : private crypto {

private:
    DWORD valueMap(DWORD value);
    void ExchangeBox();
    void BF_Fn(DWORD* L, DWORD* R);
    void BF_Fn2(DWORD* L, DWORD* R);
    int  work_process(void (BlowFish::* func)(DWORD*, DWORD*), BYTE* lp_flag);

  
    DWORD (*s_box)[256];//ֻ����ָ��
    DWORD *p_box;//ֻ����ָ��

    void show(BYTE* data, int len) {
        int i;
        for (i = 0; i < len; i++) {
            printf("0x%02X,", data[i]);
            if ((i + 1) % 8 == 0) {
                printf("\n");
            }
        }
    }
    void show_ascii(BYTE* data, int len) {
        int i;
        for (i = 0; i < len; i++) {
            printf("%c,", data[i]);
        }
        printf("\n");
    }
    //void freeEnc() {
    //    if (m_lp_enc_data) {
    //        delete[] m_lp_enc_data;
    //        m_lp_enc_data = 0;
    //    }
    //    if (m_lp_output) {
    //        delete[] m_lp_output;
    //        m_lp_output = 0;
    //    }
    //}
    //
    //void FreeDec() {
    //    if (m_lp_dec_data) {
    //        delete[] m_lp_dec_data;
    //        m_lp_dec_data = 0;
    //    }
    //    if (m_lp_output) {
    //        delete[] m_lp_output;
    //        m_lp_output = 0;
    //    }
    //}
  
public:

  //  typedef void (BlowFish::* xx)(DWORD*, DWORD*);

    //BlowFish(BYTE* lp_key, DWORD dw_keyLen) :crypto(lp_key, dw_keyLen) {
    BlowFish(BYTE* lp_key, DWORD dw_keyLen):crypto(lp_key,dw_keyLen) {


    }
    void initBox(unsigned long (*lp_s_box)[256], unsigned long* lp_p_box) {

        s_box = (DWORD(*)[256]) (new DWORD[4 * 256]);
        memcpy(s_box, lp_s_box, 4 * 256 * 4);

        p_box = new DWORD[18];
        memcpy(p_box, lp_p_box, 18 * 4);

        ExchangeBox();
    }
    void enc(BYTE* data, int dataLen) {
        int dataLen_Bak = dataLen;

        //����Ҫ����� data_enc
        if (dataLen == 0||data==0) {
            return;
        }
        if (dataLen % 8) {
            dataLen = (dataLen / 8 + 1) * 8;
        }

        //�ͷ���Դ
        if (m_lp_enc_data) {
            delete[] m_lp_enc_data;
            m_lp_enc_data = 0;
        }
        if (m_lp_output) {
            delete[] m_lp_output;
            m_lp_output = 0;
        }

        m_dw_dataLen = dataLen;

        m_lp_enc_data= new BYTE[dataLen];
        memset(m_lp_enc_data, 0, dataLen);

        m_lp_output = new BYTE[dataLen];
        memset(m_lp_output, 0, dataLen);

        memcpy(m_lp_enc_data, data, dataLen_Bak);
        
        void (BlowFish:: * ptr)(DWORD*, DWORD*) = &BlowFish::BF_Fn;
        work_process( ptr, m_lp_enc_data);
        return ;
    }

    void dec(BYTE* data, int dataLen) {
        int dataLen_Bak = dataLen;

        //����Ҫ����� data_enc
        if (dataLen == 0||data==0) {
            return ;
        }
        if (dataLen % 8) {
            dataLen = (dataLen / 8 + 1) * 8;
        }

        //�ͷ���Դ
        if (m_lp_dec_data) {
            delete[] m_lp_dec_data;
            m_lp_dec_data = 0;
        }
        if (m_lp_output) {
            delete[] m_lp_output;
            m_lp_output = 0;
        }


        m_dw_dataLen = dataLen;

        m_lp_dec_data = new BYTE[dataLen];
        memset(m_lp_dec_data, 0, dataLen);

        m_lp_output = new BYTE[dataLen];
        memset(m_lp_output, 0, dataLen);

        memcpy(m_lp_dec_data, data, dataLen_Bak);

        void (BlowFish:: * ptr)(DWORD*, DWORD*) = &BlowFish::BF_Fn2;
        work_process(ptr, m_lp_dec_data);
        return;
     
    }

    void show_enc(int is_ascii) {
        if (m_lp_enc_data) {
            if (is_ascii) {
                show_ascii(m_lp_enc_data, m_dw_dataLen);
            }
            else {
                show(m_lp_enc_data, m_dw_dataLen);
            }
            
        }
        return ;
    }
    void show_dec(int is_ascii) {
        if ( m_lp_dec_data) {
            if (is_ascii) {
                show_ascii(m_lp_dec_data, m_dw_dataLen);
            }
            else {
                show(m_lp_dec_data, m_dw_dataLen);
            }
            
        }
        return ;
    }
    void show_output(int is_ascii) {
        if (m_lp_output) {
            if (is_ascii) {
                show_ascii(m_lp_output, m_dw_dataLen);
            }
            else {
                show(m_lp_output, m_dw_dataLen);
            }
            
        }
        return ;
    }
    BYTE* getEncData() {
        return m_lp_enc_data;
    }
    BYTE* getDecData() {
        return m_lp_dec_data;
    }
 
};

DWORD  BlowFish::valueMap(DWORD dw_L)
{
    DWORD dw_Ret;

    //������� ÿһ���ֽڲ�һ�α� Ȼ����мӺ�������
    dw_Ret = s_box[0][dw_L >> 24] + s_box[1][(dw_L >> 16) & 0xff];
    dw_Ret ^= s_box[2][(dw_L >> 8) & 0xff];
    dw_Ret += s_box[3][dw_L & 0xff];

    return dw_Ret;
}


void BlowFish::BF_Fn(DWORD* p_dw_L, DWORD* p_dw_R)
{
    int i;
    DWORD temp;

    for (i = 0; i < 8; i++) {
        *p_dw_L ^= p_box[2 * i + 0];
        *p_dw_R ^= valueMap(*p_dw_L);
        *p_dw_R ^= p_box[2 * i + 1];
        *p_dw_L ^= valueMap(*p_dw_R);
         
    }

    *p_dw_L ^= p_box[16];
    *p_dw_R ^= p_box[17];

    
    temp = *p_dw_L;
    *p_dw_L = *p_dw_R;
    *p_dw_R = temp;

}

void BlowFish::BF_Fn2(DWORD* L, DWORD* R)
{
    int i;
    DWORD temp;

    //��󽻻�һ��
    temp = *L;
    *L = *R;
    *R = temp;

    *L ^= p_box[16];
    *R ^= p_box[17];

    for (i = 7; i >= 0; i--) {
       
        temp = p_box[2 * i + 0];
        *L ^= valueMap(*R) ^ temp;
        *R ^= valueMap((*L) ^ temp) ^ p_box[2 * i + 1];

    }
}
void BlowFish::ExchangeBox()
{
    int i, j;
   
    DWORD* lp_dw_key = NULL;
    DWORD dw_L = 0, dw_R = 0;//�õ�����64bit������������
    DWORD dw_KeyLen = m_dw_keyLen;

    lp_dw_key = (DWORD*)malloc(dw_KeyLen);//��ȡӦ�õĿռ�

    memset(lp_dw_key, 0, m_dw_keyLen);
    dw_KeyLen = dw_KeyLen / 4;

    
    for (i = 0; i < dw_KeyLen; i++) {
        lp_dw_key[i] = _byteswap_ulong(*((DWORD*)m_lp_key + i));
       
    }
    

    for (i = 0; i < 18; i++) {//�������
       p_box[i] ^= lp_dw_key[i % dw_KeyLen];
    }

    dw_L = dw_R = 0;//����һ��64λȫ0����
    for (i = 0; i < 18; i += 2) {//�任pBox
        BF_Fn(&dw_L, &dw_R);
        p_box[i] = dw_L;
        p_box[i + 1] = dw_R;
    }

    for (i = 0; i < 4; i++) {//�任sBox
        for (j = 0; j < 256; j += 2) {//256 / 2 == 128
            BF_Fn(&dw_L, &dw_R);
            s_box[i][j] = dw_L;
            s_box[i][j + 1] = dw_R;
        }
    }
    free(lp_dw_key);
}
int BlowFish::work_process(void (BlowFish::* func)(DWORD*,DWORD*) , BYTE* lp_flag)
 
{
    int i;
    int dw_dataLen = m_dw_dataLen / 8;
    DWORD dw_L, dw_R;
    BYTE* output = m_lp_output;
     
    for (i = 0; i < dw_dataLen; i++) {
        //һ���Լ���8�ֽ�
        dw_L = _byteswap_ulong(*((DWORD*)lp_flag));
        dw_R = _byteswap_ulong(*((DWORD*)lp_flag + 1));

        (this->*func)(&dw_L, &dw_R);
 
        *((DWORD*)output) = _byteswap_ulong(dw_L);
        *((DWORD*)output + 1) = _byteswap_ulong(dw_R);
        lp_flag += 8;//ָ����һ�����ݿ�
        output += 8;
    }
    return 0;
}

//int main() {
//  
//    BYTE key[] = "SnVzdF9BX1NlY3Jl";
//    BlowFish* xx = new BlowFish(key,strlen((const char*)key));
//    xx->initBox(g_s_box, g_p_box);
//
//    BYTE data[] = "qwerasdf1234567887654321";
//    xx->enc(data, 24);
//    xx->show_enc(0);
//
//    xx->dec(xx->getEncData(), 24);
//    xx->show_dec(1);
//
// 
//    delete xx;
//    return 0;
//}