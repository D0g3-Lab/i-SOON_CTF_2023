#pragma once

#include<Windows.h>
#include "crypt0.h"

class Bl0wFish : private crypt0 {

private:
    DWORD valueMap(DWORD value);
    void ExchangeBox();
    void BF_Fn(DWORD* L, DWORD* R);
    void BF_Fn2(DWORD* L, DWORD* R);
    int  work_process(void (Bl0wFish::* func)(DWORD*, DWORD*), BYTE* lp_flag);


    DWORD(*s_box)[256];//ֻ����ָ��
    DWORD* p_box;//ֻ����ָ��
    void show(BYTE* data, int len);
    void show_ascii(BYTE* data, int len);

public:
    int m_statuc[2];

    Bl0wFish(BYTE* lp_key, DWORD dw_keyLen) :crypt0(lp_key, dw_keyLen) 
    {
        m_statuc[0] = 1;
    }
    void initBox(unsigned long(*lp_s_box)[256], unsigned long* lp_p_box);
    void enc(BYTE* data, int dataLen);
    void dec(BYTE* data, int dataLen);
    void show_enc(int is_ascii);
    void show_dec(int is_ascii);
    void show_output(int is_ascii);
    BYTE* get_outPut();
    DWORD get_m_dw_dataLen();
};

