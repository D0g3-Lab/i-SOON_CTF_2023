#include "Bl0wFish.h"
#include<stdio.h>

void Bl0wFish::initBox(unsigned long(*lp_s_box)[256], unsigned long* lp_p_box) {

    m_statuc[1] = 1;
    s_box = (DWORD(*)[256]) (new DWORD[4 * 256]);
    memcpy(s_box, lp_s_box, 4 * 256 * 4);

    p_box = new DWORD[18];
    memcpy(p_box, lp_p_box, 18 * 4);

    ExchangeBox();
}
void Bl0wFish::enc(BYTE* data, int dataLen) {
    int dataLen_Bak = dataLen;

    //����Ҫ����� data_enc
    if (dataLen == 0 || data == 0 || m_statuc[0]!=1|| m_statuc[1] != 1) {
        return;
    }
    if (dataLen % 8) {
        dataLen = (dataLen / 8 + 1) * 8;
    }

    //�ͷ���Դ
    if (m_lp_enc_data) {
        delete[] m_lp_enc_data;
        m_lp_enc_data = 0;
    }
    if (m_lp_output) {
        delete[] m_lp_output;
        m_lp_output = 0;
    }

    m_dw_dataLen = dataLen;

    m_lp_enc_data = new BYTE[dataLen];
    memset(m_lp_enc_data, 0, dataLen);

    m_lp_output = new BYTE[dataLen];
    memset(m_lp_output, 0, dataLen);

    memcpy(m_lp_enc_data, data, dataLen_Bak);

    void (Bl0wFish:: * ptr)(DWORD*, DWORD*) = &Bl0wFish::BF_Fn;
    work_process(ptr, m_lp_enc_data);
    return;
}

void  Bl0wFish::dec(BYTE* data, int dataLen) {
    int dataLen_Bak = dataLen;

    //����Ҫ����� data_enc
    if (dataLen == 0 || data == 0 || m_statuc[0] != 1 || m_statuc[1] != 1) {
        return;
    }
    if (dataLen % 8) {
        dataLen = (dataLen / 8 + 1) * 8;
    }

    //�ͷ���Դ
    if (m_lp_dec_data) {
        delete[] m_lp_dec_data;
        m_lp_dec_data = 0;
    }
    if (m_lp_output) {
        delete[] m_lp_output;
        m_lp_output = 0;
    }
    m_dw_dataLen = dataLen;

    m_lp_dec_data = new BYTE[dataLen];
    memset(m_lp_dec_data, 0, dataLen);

    m_lp_output = new BYTE[dataLen];
    memset(m_lp_output, 0, dataLen);

    memcpy(m_lp_dec_data, data, dataLen_Bak);

    void (Bl0wFish:: * ptr)(DWORD*, DWORD*) = &Bl0wFish::BF_Fn2;
    work_process(ptr, m_lp_dec_data);
    return;

}

void  Bl0wFish::show_enc(int is_ascii) {
    if (m_lp_enc_data) {
        if (is_ascii) {
            show_ascii(m_lp_enc_data, m_dw_dataLen);
        }
        else {
            show(m_lp_enc_data, m_dw_dataLen);
        }

    }
    return;
}
void  Bl0wFish::show_dec(int is_ascii) {
    if (m_lp_dec_data) {
        if (is_ascii) {
            show_ascii(m_lp_dec_data, m_dw_dataLen);
        }
        else {
            show(m_lp_dec_data, m_dw_dataLen);
        }

    }
    return;
}
void  Bl0wFish::show_output(int is_ascii) {
    if (m_lp_output) {
        if (is_ascii) {
            show_ascii(m_lp_output, m_dw_dataLen);
        }
        else {
            show(m_lp_output, m_dw_dataLen);
        }

    }
    return;
}
BYTE* Bl0wFish::get_outPut() {
    return m_lp_output;
}
DWORD Bl0wFish::get_m_dw_dataLen() {
    return m_dw_dataLen;
}

void Bl0wFish::show(BYTE* data, int len) {
    int i;
    for (i = 0; i < len; i++) {
        printf("0x%02X,", data[i]);
        if ((i + 1) % 8 == 0) {
            printf("\n");
        }
    }
}
void Bl0wFish::show_ascii(BYTE* data, int len) {
    int i;
    for (i = 0; i < len; i++) {
        printf("%c,", data[i]);
    }
    printf("\n");
}

DWORD  Bl0wFish::valueMap(DWORD dw_L)
{
    DWORD dw_Ret;

    //������� ÿһ���ֽڲ�һ�α� Ȼ����мӺ�������
    dw_Ret = s_box[0][dw_L >> 24] + s_box[1][(dw_L >> 16) & 0xff];
    dw_Ret ^= s_box[2][(dw_L >> 8) & 0xff];
    dw_Ret += s_box[3][dw_L & 0xff];

    return dw_Ret;
}


void Bl0wFish::BF_Fn(DWORD* p_dw_L, DWORD* p_dw_R)
{
    int i;
    DWORD temp;

    for (i = 0; i < 8; i++) {
        *p_dw_L ^= p_box[2 * i + 0];
        *p_dw_R ^= valueMap(*p_dw_L);
        *p_dw_R ^= p_box[2 * i + 1];
        *p_dw_L ^= valueMap(*p_dw_R);

    }

    *p_dw_L ^= p_box[16];
    *p_dw_R ^= p_box[17];


    temp = *p_dw_L;
    *p_dw_L = *p_dw_R;
    *p_dw_R = temp;

}

void Bl0wFish::BF_Fn2(DWORD* L, DWORD* R)
{
    int i;
    DWORD temp;

    //��󽻻�һ��
    temp = *L;
    *L = *R;
    *R = temp;

    *L ^= p_box[16];
    *R ^= p_box[17];

    for (i = 7; i >= 0; i--) {

        temp = p_box[2 * i + 0];
        *L ^= valueMap(*R) ^ temp;
        *R ^= valueMap((*L) ^ temp) ^ p_box[2 * i + 1];

    }
}
void Bl0wFish::ExchangeBox()
{
    int i, j;

    DWORD* lp_dw_key = NULL;
    DWORD dw_L = 0, dw_R = 0;//�õ�����64bit������������
    DWORD dw_KeyLen = m_dw_keyLen;

    lp_dw_key = (DWORD*)malloc(dw_KeyLen);//��ȡӦ�õĿռ�

    memset(lp_dw_key, 0, m_dw_keyLen);

    dw_KeyLen = dw_KeyLen / 4;//�����������


    for (i = 0; i < dw_KeyLen; i++) {
        lp_dw_key[i] = _byteswap_ulong(*((DWORD*)m_lp_key + i));

    }


    for (i = 0; i < 18; i++) {//�������
        p_box[i] ^= lp_dw_key[i % dw_KeyLen];
    }

    dw_L = dw_R = 0;//����һ��64λȫ0����
    for (i = 0; i < 18; i += 2) {//�任pBox
        BF_Fn(&dw_L, &dw_R);
        p_box[i] = dw_L;
        p_box[i + 1] = dw_R;
    }

    for (i = 0; i < 4; i++) {//�任sBox
        for (j = 0; j < 256; j += 2) {//256 / 2 == 128
            BF_Fn(&dw_L, &dw_R);
            s_box[i][j] = dw_L;
            s_box[i][j + 1] = dw_R;
        }
    }
    free(lp_dw_key);
}
int Bl0wFish::work_process(void (Bl0wFish::* func)(DWORD*, DWORD*), BYTE* lp_flag)

{
    int i;
    int dw_dataLen = m_dw_dataLen / 8;
    DWORD dw_L, dw_R;
    BYTE* output = m_lp_output;

    for (i = 0; i < dw_dataLen; i++) {
        //һ���Լ���8�ֽ�
        dw_L = _byteswap_ulong(*((DWORD*)lp_flag));
        dw_R = _byteswap_ulong(*((DWORD*)lp_flag + 1));

        (this->*func)(&dw_L, &dw_R);

        *((DWORD*)output) = _byteswap_ulong(dw_L);
        *((DWORD*)output + 1) = _byteswap_ulong(dw_R);
        lp_flag += 8;//ָ����һ�����ݿ�
        output += 8;
    }
    return 0;
}
