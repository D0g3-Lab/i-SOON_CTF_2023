#pragma once
#include<Windows.h>
class crypt0
{

public:
    crypt0();
    crypt0(BYTE* lp_key, DWORD dw_keyLen);
    ~crypt0();
    virtual void show_enc(int) = 0;
    virtual void show_dec(int) = 0;
    virtual void show_output(int) = 0;

protected:
    BYTE* m_lp_key = 0;
    DWORD m_dw_keyLen = 0;

    BYTE* m_lp_enc_data = 0;
    BYTE* m_lp_dec_data = 0;
    BYTE* m_lp_output = 0;
    DWORD m_dw_dataLen = 0;
};