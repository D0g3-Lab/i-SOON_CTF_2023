#pragma once
#include<Windows.h>

class checkMe {
public:
    checkMe();
    ~checkMe();
    void init_datacmp(BYTE* src, int len);
    void operate_input(BYTE* szUser, int uLen, BYTE* passwd, int pLen);
    void check_data();
private:
    BYTE* m_lp_datacmp;
    BYTE* m_lp_dataEnc;
    DWORD m_src_len;
    DWORD m_des_len;
};

