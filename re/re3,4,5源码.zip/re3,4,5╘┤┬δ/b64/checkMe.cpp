#include "checkMe.h"
#include "Bl0wFish.h"
#include"fish_data.h"

checkMe::checkMe() {

}
checkMe::~checkMe() {
    if (m_lp_datacmp) {
        delete[]m_lp_datacmp;
    }
    if (m_lp_dataEnc) {
        delete[] m_lp_dataEnc;
    }
}
void checkMe::init_datacmp(BYTE* src, int len) {
    m_lp_datacmp = new BYTE[len];
    memcpy(m_lp_datacmp, src, len);
    m_src_len = len;
}
void checkMe::operate_input(BYTE* szUser, int uLen, BYTE* passwd, int pLen) {
    //BYTE datacmp_Arr[] = {
    //0xce,0x6d,0x18,0xb3,
    //0x08,0x54 ,0xc0 ,0xdf,
    //0x78,0x1a,0xae,0xa1,
    //0xbd,0xc9,0x41,0x5a,
    //};
    Bl0wFish* xx = new Bl0wFish((BYTE*)szUser, (DWORD)uLen);
    

    xx->initBox(g_s_box, g_p_box);
    xx->enc((BYTE*)passwd, pLen);
   // xx->dec((BYTE*)datacmp_Arr, 16);
    //BYTE* test;
    //test = new BYTE[xx->get_m_dw_dataLen()];
    //memcpy(test, xx->get_outPut(), xx->get_m_dw_dataLen());
    //xx->dec(test, xx->get_m_dw_dataLen());
    //test=xx->get_outPut();

    m_des_len = xx->get_m_dw_dataLen();
    m_lp_dataEnc = new BYTE[m_des_len];
    memcpy(m_lp_dataEnc, xx->get_outPut(), m_des_len);


    delete xx;
}
void checkMe::check_data() {
    int i;
    char sztip[] = { 't','i','p','\0' };
    char szYES[] = { 'Y','o','u',' ','G','e','t',' ','I','t','!','\0' };
    char szNO1[] = { 'W','r','o','n','g',' ','u','s','e','r','/','p','a','s','s','w','d','\0' };
    //char szNO2[] = { 'W','r','o','n','g',' ','L','e','n','\0' };

    if (!(m_des_len ^ m_src_len)) {
        if (!memcmp(m_lp_datacmp, m_lp_dataEnc, m_des_len)) {
            MessageBoxA(0, szYES, sztip, 0);
        }
        else {
            MessageBoxA(0, szNO1, sztip,  0);
        }
    }
    else {
        MessageBoxA(0, szNO1, sztip,  0);
    }
    //ExitProcess(0);
    return;
}