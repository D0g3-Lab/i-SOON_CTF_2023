#include "crypt0.h"

crypt0::crypt0() {

}
crypt0::crypt0(BYTE* lp_key, DWORD dw_keyLen) {
    int len_bak = dw_keyLen;
    
    if (dw_keyLen == 0) {
        m_dw_keyLen = 0;
        return;
    }
    if (dw_keyLen % 8) {
        dw_keyLen = (dw_keyLen / 8 + 1) * 8;
    }
    m_lp_key = new BYTE[dw_keyLen];
    memset(m_lp_key, 0, dw_keyLen);
    memcpy(m_lp_key, lp_key, len_bak);
    m_dw_keyLen = dw_keyLen;
}
crypt0::~crypt0() {

    if (m_lp_key) {
        delete[] m_lp_key;
    }
    if (m_lp_enc_data) {
        delete[] m_lp_enc_data;
    }
    if (m_lp_dec_data) {
        delete[] m_lp_dec_data;
    }
    if (m_lp_output) {
        delete[] m_lp_output;
    }
}
